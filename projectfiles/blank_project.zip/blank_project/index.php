
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">

  <title></title>
  <meta name="description" content="simpson.web project">
  <meta name="author" content="simpson.web">

  <link rel="stylesheet" href="css/meyerReset.css">
  <link rel="stylesheet" href="css/style.css">

  <!--[if lt IE 9]>
  <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->
</head>

<body>
<div id="header">simpsonweb real estate</div>
<p>Please sign up on our guest list and a representative will contact you soon</p>
<br />
  <form method="POST" action="formHandler.php" >
    firstname<br />
    <input type="text" name="firstName" id="firstName" size="30" /><br />
    lastname<br />
    <input type="text" name="lastName" id="lastName" size="30" /><br />
    <br />
    Contact Information<br />
    email
    <input type="radio" name="rcontactInfo" value="email" id="email" size="15" />
    phone
    <input type="radio" name="rcontactInfo" value="phone" id="phone" size="15" /><br />
    <input type="text" name="contactInfo" id="contactInfo" size="30" /><br />
    <select name="eventType">
      <option value="manchester">manchester</option>
      <option value="london">london</option>
      <option value="amsterdam">amsterdam</option>
      <option value="toronto">toronto</option>
    </select>
    <br />
    <textarea rows="6" cols="50" name="comments" ></textarea>
    <input type="submit" value="submit" />
  </form>
  <script src="js/library/jquery.js"></script>
  <script src="js/main.js"></script>
</body>
</html>